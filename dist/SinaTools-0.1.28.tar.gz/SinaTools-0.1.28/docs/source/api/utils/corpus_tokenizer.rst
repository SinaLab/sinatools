sinatools.utils.corpus_tokenizer
+++++++++++++++++++++++++++++++

.. automodule:: sinatools.utils.corpus_tokenizer
   :members: