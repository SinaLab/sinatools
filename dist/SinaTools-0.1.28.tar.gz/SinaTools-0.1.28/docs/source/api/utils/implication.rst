sinatools.utils.implication
++++++++++++++++++++++++++

.. automodule:: sinatools.utils.implication
   :members: