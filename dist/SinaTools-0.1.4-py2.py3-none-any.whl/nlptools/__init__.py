"""Top-level package for nlptools."""

__author__ = """SinaLab"""
__email__ = 'sina.institute.bzu@gmail.com'
__version__ = '0.8.5'