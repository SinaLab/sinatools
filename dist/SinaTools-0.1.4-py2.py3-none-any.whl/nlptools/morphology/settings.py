flag = True
div_dic = {}
lemma_source = "DIC"

#two_grams_dict =  {}
#three_grams_dict = {}
#four_grams_dict = {}
#five_grams_dict = {}
