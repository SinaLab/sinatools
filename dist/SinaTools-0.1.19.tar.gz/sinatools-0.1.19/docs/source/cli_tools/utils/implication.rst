sinatools.CLI.utils.implication
++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.implication
   :members: