sinatools.CLI.morphology.morph_analyzer
++++++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.morphology.morph_analyzer
   :members: