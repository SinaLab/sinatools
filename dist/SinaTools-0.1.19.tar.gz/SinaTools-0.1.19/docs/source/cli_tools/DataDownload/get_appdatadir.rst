CLI.DataDownload.get_appdatadir
++++++++++++++++++++++++++++++

.. automodule:: CLI.DataDownload.get_appdatadir
   :members: