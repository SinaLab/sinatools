sinatools.CLI.DataDownload.download_files
++++++++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.DataDownload.download_files
   :members: