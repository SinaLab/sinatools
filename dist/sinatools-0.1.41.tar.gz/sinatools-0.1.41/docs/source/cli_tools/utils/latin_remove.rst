sinatools.CLI.utils.latin_remove
+++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.latin_remove
   :members: