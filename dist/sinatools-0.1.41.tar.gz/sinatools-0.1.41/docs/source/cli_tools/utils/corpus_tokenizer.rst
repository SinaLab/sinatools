sinatools.CLI.utils.corpus_tokenizer
+++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.corpus_tokenizer
   :members: