sinatools.salma
==============


.. automodule:: sinatools.salma
   :members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   salma/views