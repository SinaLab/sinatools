sinatools.utils
==============


.. automodule:: sinatools.utils
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   utils/parser
   utils/implication
   utils/jaccard
   utils/text_transliteration
   utils/sentence_tokenizer
   utils/corpus_tokenizer