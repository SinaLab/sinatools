Overview
========


About
-----

Sina Tools is a collection of Arabic natural language processing tools created by the Sina Lab at Birzeit University in Palestine. 

For additional details, please refer to the :doc:`installation` section.

Sina Tools is available under the MIT license. See :doc:`License` for more information.

.. _Github repo: https://github.com/SinaLab/sinatools
.. _tarball: https://github.com/SinaLab/sinatools/tarball/master
