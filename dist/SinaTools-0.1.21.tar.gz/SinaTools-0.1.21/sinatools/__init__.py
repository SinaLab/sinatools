"""Top-level package for sinatools."""

__author__ = """SinaLab"""
__email__ = 'sina.institute.bzu@gmail.com'
__version__ = '0.8.5'