SinaTools
---------

Open-source Python toolkit for Arabic Natural Understanding, allowing people to integrate it in their system workflow.

Python APIs, command lines, colabs, and online demos.

* Free software: MIT license
* Documentation: https://sina.birzeit.edu/sinatools/
