sinatools.DataDownload
=====================


.. automodule:: sinatools.DataDownload
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   DataDownload/downloader
