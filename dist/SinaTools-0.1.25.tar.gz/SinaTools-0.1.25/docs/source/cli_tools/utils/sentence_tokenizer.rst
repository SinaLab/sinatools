sinatools.CLI.utils.sentence_tokenizer
+++++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.sentence_tokenizer
   :members: