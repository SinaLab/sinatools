sinatools.CLI.utils
==================


.. automodule:: sinatools.CLI.utils
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   utils/arStrip
   utils/latin_remove
   utils/remove_punc
   utils/implication
   utils/sentence_tokenizer
   utils/text_transliteration
   utils/jaccard
   utils/corpus_tokenizer