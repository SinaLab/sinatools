sinatools.CLI.ner.entity_extractor
+++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.ner.entity_extractor
   :members: