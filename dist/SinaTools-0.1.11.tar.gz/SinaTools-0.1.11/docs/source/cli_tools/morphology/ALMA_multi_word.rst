sinatools.CLI.morphology.ALMA_multi_word
+++++++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.morphology.ALMA_multi_word
   :members: