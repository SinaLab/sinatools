sinatools.utils.jaccard
++++++++++++++++++++++

.. automodule:: sinatools.utils.jaccard
   :members: