from nlptools.arabiner.nn.BaseModel import BaseModel
from nlptools.arabiner.nn.BertSeqTagger import BertSeqTagger
from nlptools.arabiner.nn.BertNestedTagger import BertNestedTagger