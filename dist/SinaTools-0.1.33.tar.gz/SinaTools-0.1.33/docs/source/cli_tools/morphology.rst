sinatools.CLI.morphology
=======================


.. automodule:: sinatools.CLI.morphology
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   morphology/morph_analyzer
   morphology/ALMA_multi_word
   
   
   
   
   
   