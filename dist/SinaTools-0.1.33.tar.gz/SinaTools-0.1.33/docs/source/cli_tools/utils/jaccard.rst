sinatools.CLI.utils.jaccard
+++++++++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.jaccard
   :members: