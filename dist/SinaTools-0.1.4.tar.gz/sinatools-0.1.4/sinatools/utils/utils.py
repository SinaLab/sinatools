def hello():
    return 'hello'