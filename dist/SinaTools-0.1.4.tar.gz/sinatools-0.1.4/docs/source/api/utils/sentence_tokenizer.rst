sinatools.utils.sentence_tokenizer
+++++++++++++++++++++++++++++++++

.. automodule:: sinatools.utils.sentence_tokenizer
   :members: