sinatools.CLI.arabiner.bin.infer
+++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.arabiner.bin.infer
   :members: