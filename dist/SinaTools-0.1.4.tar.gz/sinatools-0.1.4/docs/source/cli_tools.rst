SinaTools Command Line
=======================
.. toctree::
   :maxdepth: 2
   :titlesonly:
   :caption: Modules:

 
   cli_tools/utils
   cli_tools/morphology
   cli_tools/arabiner
   cli_tools/salma
   cli_tools/DataDownload
         



