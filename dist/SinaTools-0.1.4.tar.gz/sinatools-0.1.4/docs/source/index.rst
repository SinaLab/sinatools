SinaTools Documentation
=======================

.. image:: _images/SinaLogo.jpg
   :alt: SinaTools Logo

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   about
   installation
   cli_tools
   api
   License




