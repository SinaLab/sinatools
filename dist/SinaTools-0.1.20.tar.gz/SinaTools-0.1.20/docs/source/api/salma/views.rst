sinatools.salma.views
++++++++++++++++++++


.. automodule:: sinatools.salma.views
   :members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:
