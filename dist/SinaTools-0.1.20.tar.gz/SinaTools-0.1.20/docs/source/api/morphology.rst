sinatools.morphology
===================


.. automodule:: sinatools.morphology
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   morphology/morph_analyzer
