sinatools.CLI.utils.arStrip
++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.arStrip
   :members: