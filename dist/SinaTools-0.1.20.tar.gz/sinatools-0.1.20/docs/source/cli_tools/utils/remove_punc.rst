sinatools.CLI.utils.remove_punc
++++++++++++++++++++++++++++++

.. automodule:: sinatools.CLI.utils.remove_punc
   :members: