sinatools.CLI.DataDownload
=========================


.. automodule:: sinatools.CLI.DataDownload
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   DataDownload/download_files
