sinatools.ner
=================


.. automodule:: sinatools.ner
   :members:
   :undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 1
   :caption: Modules:

   ner/entity_extractor