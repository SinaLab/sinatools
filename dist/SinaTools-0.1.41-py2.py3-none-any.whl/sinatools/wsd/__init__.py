from sinatools.wsd import settings 
import pickle
from sinatools.DataDownload import downloader
import os 

glosses_dic = {}
filename = 'one_gram.pickle'
path =downloader.get_appdatadir()
file_path = os.path.join(path, filename)
with open(file_path, 'rb') as f:
    glosses_dic = pickle.load(f)
